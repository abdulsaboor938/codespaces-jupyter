public class server {

}
