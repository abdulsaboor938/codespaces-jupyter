/*
This file contains the order in which things should be learnt
- pipes
- fifo
- file handling
- shell command execution
- passing arguments through terminal
- genral syntaxes
*/